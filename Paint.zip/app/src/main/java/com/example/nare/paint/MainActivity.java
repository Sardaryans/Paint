package com.example.nare.paint;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;

import android.widget.PopupWindow;
import android.widget.SeekBar;


public class MainActivity extends AppCompatActivity {

    Button btnClear, btnUndo, btnblack, btnred, btnblue, btngreen, btngrey, btnyellow,btnpen,btnret,btnsize;
    MyView myView;
    PopupWindow popupWindow;
    LayoutInflater layoutInflater;
    int prog = 10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);




        myView = (MyView) findViewById(R.id.myView);
        btnClear = (Button) findViewById(R.id.btnClear);
        btnUndo = (Button) findViewById(R.id.btnUndo);
        btnblack = (Button) findViewById(R.id.black);
        btnblue = (Button) findViewById(R.id.blue);
        btnred = (Button) findViewById(R.id.red);
        btngreen = (Button) findViewById(R.id.green);
        btngrey = (Button) findViewById(R.id.gray);
        btnyellow = (Button) findViewById(R.id.yellow);
        btnpen = (Button) findViewById(R.id.pen);
        btnret = (Button) findViewById(R.id.btnret);
        btnsize = (Button) findViewById(R.id.btnsize);

        btnsize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);
                    ViewGroup container = (ViewGroup) layoutInflater.inflate(R.layout.popup_window, null);


                    popupWindow = new PopupWindow(container, 400, 50, true);
                    popupWindow.showAtLocation(myView, Gravity.NO_GRAVITY, 100, 80);

                    SeekBar seekBar = (SeekBar)container.findViewById(R.id.seekbar);
                    seekBar.setProgress(prog);

                    seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            prog = progress;
                            myView.setCurentsize(prog);

                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });


                    container.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {

                            popupWindow.dismiss();
                            return true;
                        }
                    });
                }


        });

        btnpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.BLACK);
            }
        });
        btnret.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.WHITE);
            }
        });
        btngrey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.GRAY);
            }
        });
        btnyellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {myView.setCurentcolor(Color.YELLOW);}
        });
        btnblack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.BLACK);
            }
        });
        btngreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.GREEN);
            }
        });
        btnred.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.RED);
            }
        });
        btnblue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.setCurentcolor(Color.BLUE);
            }
        });
        btnUndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.undo();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myView.cleanBac();
            }
        });
    }
}
